package com.upendra.security;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlightAdminSecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
