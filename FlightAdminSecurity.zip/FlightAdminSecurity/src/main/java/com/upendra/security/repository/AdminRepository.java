package com.upendra.security.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.upendra.security.model.UserModel;

public interface AdminRepository extends MongoRepository<UserModel, String>{

	UserModel findByusername(String username);

}
