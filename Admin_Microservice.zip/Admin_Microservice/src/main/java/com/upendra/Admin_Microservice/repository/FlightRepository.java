package com.upendra.Admin_Microservice.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.upendra.Admin_Microservice.model.Flight;

public interface FlightRepository extends MongoRepository<Flight,Integer> {

	

}
