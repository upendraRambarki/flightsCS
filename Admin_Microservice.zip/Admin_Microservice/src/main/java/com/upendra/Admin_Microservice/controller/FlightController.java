package com.upendra.Admin_Microservice.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.upendra.Admin_Microservice.exceptions.ResourceNotFoundException;
import com.upendra.Admin_Microservice.model.Flight;
import com.upendra.Admin_Microservice.service.FlightService;


@RestController
@RequestMapping("/flights")
public class FlightController {	
	@Autowired
	FlightService flightService;
	@GetMapping("/getFlights")
	public List<Flight> getFlights(){
		return flightService.getFlights();
	}
	@PostMapping("/addFlights")
	public void addFlight( @RequestBody Flight flight) {
		flightService.addFlight(flight);
	}
	@GetMapping("/getFlightById/{flightNumber}")
	public ResponseEntity <Flight> getFlightById(@PathVariable(value = "flightNumber") int flightNumber)
			throws ResourceNotFoundException{
		Flight flight = flightService.getFlight(flightNumber);
		return ResponseEntity.ok().body(flight);
	}
	@PutMapping("/updateFlight/{id}")
	public ResponseEntity <Flight> updateFlightById(@PathVariable(value = "id") int flightId, 
			@RequestBody Flight flight) throws ResourceNotFoundException {
			
			Flight updatedFlight = flightService.updateFlight(flightId, flight);
			return ResponseEntity.ok().body(updatedFlight);
	}
	@DeleteMapping("/deleteFlights/{id}")
    public Map<String, Boolean> deleteFligh(@PathVariable(value = "id") int flightId)
    throws ResourceNotFoundException {
        flightService.deleteFlight(flightId);
        Map < String, Boolean > response = new HashMap<>();
        response.put("deleted", Boolean.TRUE);
        return response;
    }	
	
}
