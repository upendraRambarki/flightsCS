package com.upendra.Admin_Microservice.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.upendra.Admin_Microservice.exceptions.ResourceNotFoundException;
import com.upendra.Admin_Microservice.model.Flight;
import com.upendra.Admin_Microservice.repository.FlightRepository;
@Service
public class FlightService {
	@Autowired
	FlightRepository flightRepository;
	
	public List<Flight> getFlights() {		
		return flightRepository.findAll();
	}

	public void addFlight(Flight flight) {
		flightRepository.save(flight);		
	}

	public Flight getFlight(int flightNumber)throws ResourceNotFoundException{
		return flightRepository.findById(flightNumber)
				.orElseThrow(() -> new ResourceNotFoundException("Flight not found for this id :: " + flightNumber));
	}

	public Flight updateFlight(int id, Flight f) throws ResourceNotFoundException
	{
		Flight flight =  flightRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Flight not found for this id :: " + id));
		flight = f;
		flight.setFlightNumber(id);
		flightRepository.save(flight);
		return flight;
	}

	public Flight deleteFlight(int id) throws ResourceNotFoundException{
		Flight flight =  flightRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Flight not found for this id :: " + id));
		flightRepository.delete(flight);
		return flight;
	}

	

	

	
	
}
