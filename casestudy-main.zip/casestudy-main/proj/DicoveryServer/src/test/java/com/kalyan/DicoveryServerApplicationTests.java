package com.kalyan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DicoveryServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
