package com.upendra.Flight_ServiceAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlightServiceApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
