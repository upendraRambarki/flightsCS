package com.upendra.bookingservice.repository;
import java.util.List;
import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.upendra.bookingservice.models.PassengerList;


public interface PassengerRepo extends MongoRepository<PassengerList, String> {

	Optional<List<PassengerList>> findByUsername(String username);

}