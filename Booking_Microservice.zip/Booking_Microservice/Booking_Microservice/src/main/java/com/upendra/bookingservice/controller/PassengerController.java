package com.upendra.bookingservice.controller;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.upendra.bookingservice.exceptions.UserNotFoundException;
import com.upendra.bookingservice.models.PassengerList;
import com.upendra.bookingservice.service.PassengerService;



@RestController
@RequestMapping("/booking")
public class PassengerController {
	
	@Autowired
	private PassengerService passengerService;
	
	@PostMapping("/{flightId}/addpassengers")
	public PassengerList addpassenger(@PathVariable(value="flightId") String flightId, @RequestBody @Valid PassengerList passengerList)
	{
		return passengerService.addPassenger(flightId,passengerList);
	}
	
	@GetMapping("/getpassengers")
	public List<PassengerList> getPassenger()
	{
		return passengerService.getPassenger();
	}
	
//	@GetMapping("/getpassengers/{username}")
//	public Optional<PassengerList> getpassengersByUsername(@PathVariable(value = "username") String username)
//			throws UserNotFoundException
//	{
//
//		return passengerService.getpassenger(username);
//	}
	
	@GetMapping("/getpassengers/{username}")
	public Optional<List<PassengerList>> getpassengersById(@PathVariable(value = "username") String username)
			throws UserNotFoundException
	{
		
		
		return passengerService.getByUserName(username);
	}
	@DeleteMapping("/cancelticket/{flightId}/{userId}")
	
	public Map<String, PassengerList> cancelTicket(@PathVariable(value = "flightId") String flightId, @PathVariable(value = "userId") String userId) {
		
		return passengerService.cancelTicket(userId,flightId);
	
	}
	
	@PutMapping("/cancelticket/{flightId}/{userId}/{passengerId}")
	
	public Map<String, PassengerList> cancelTicketByPassengerId(@PathVariable(value = "flightId") String flightId
			
			, @PathVariable(value = "userId") String userId,@PathVariable(value = "passengerId") String passengerId) {
		
		return passengerService.cancelTicketbyPassengerId(userId,flightId,passengerId);
	}
	 
	

}