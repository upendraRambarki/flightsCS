package com.upendra.bookingservice.models;

public class Passenger
{
	
	String passengerfirstname;
	
	String passengerlastname;
	
	int age;
	
	String gender;
	
	String aadhar;
	
	public String getPassengerfirstname() {
		return passengerfirstname;
	}
	
	public void setPassengerfirstname(String passengerfirstname) {
		this.passengerfirstname = passengerfirstname;
	}
	
	public String getPassengerlastname() {
		return passengerlastname;
	}
	
	public void setPassengerlastname(String passengerlastname) {
		this.passengerlastname = passengerlastname;
	}
	
	public int getAge() {
		return age;
	}
	
	public void setAge(int age) {
		this.age = age;
	}
	
	public String getGender() {
		return gender;
	}
	
	public void setGender(String gender) {
		this.gender = gender;
	}
	
	public String getAadhar()
	{
		return aadhar;
	}
	
	public void setAadhar(String aadhar) 
	{
		this.aadhar = aadhar;
	}
	public Passenger() 
	{
		
		super();
		
	}
	public Passenger(String passengerfirstname, String passengerlastname, int age, String gender, String aadhar) 
	{
		
		super();
		
		this.passengerfirstname = passengerfirstname;
		
		this.passengerlastname = passengerlastname;
		
		this.age = age;
		
		this.gender = gender;
		
		this.aadhar = aadhar;
	}
	
	
}
