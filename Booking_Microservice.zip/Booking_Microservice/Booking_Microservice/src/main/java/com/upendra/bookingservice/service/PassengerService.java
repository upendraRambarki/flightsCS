package com.upendra.bookingservice.service;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.upendra.bookingservice.exceptions.UserNotFoundException;
import com.upendra.bookingservice.models.BookingFlight;
import com.upendra.bookingservice.models.Flight;
import com.upendra.bookingservice.models.Passenger;
import com.upendra.bookingservice.models.PassengerList;
import com.upendra.bookingservice.repository.PassengerRepo;



@Service
public class PassengerService 
{
	@Autowired
	private PassengerRepo passengerRepo;
	
	@Autowired
	public RestTemplate rest;
	
	public PassengerList addPassenger(String Id,PassengerList passengerList)
	{
		Flight flight = rest.getForObject("http://AdminMicroservice/flights/getFlightById/"+Id, Flight.class);
		
		BookingFlight bookingFlight = new BookingFlight(flight.getFlightNumber(),flight.getSource(),flight.getDestination(),flight.getArrivalDate(),flight.getDepartDate(),flight.getArrivalTime(),flight.getDepartTime());
		
		passengerList.setBookingFlight(bookingFlight);

		int noOfPassengers = passengerList.getPassengerlist().size();
		
		Flight updatedFlight = rest.getForObject("http://AdminMicroservice/flights/getFlightById/"+Id, Flight.class);
		
		updatedFlight.setSeatsRemaining(updatedFlight.getSeatsRemaining()-noOfPassengers);
		
		rest.put("http://AdminMicroservice/flights/updateFlight/" + Id, updatedFlight);
		
		return passengerRepo.save(passengerList);	
	}
	
	public List<PassengerList> getPassenger()
	{
		return passengerRepo.findAll();
	}
	
	public Optional<List<PassengerList>> getByUserName(String username)
	{
		return passengerRepo.findByUsername(username);
	}
	
	public Optional<PassengerList> getpassengers(String username) {
		// TODO Auto-generated method stub
		return passengerRepo.findById(username);
	}
	  public Map<String,PassengerList> cancelTicket(String userId,String Id) 
	  {
		  
	  Optional<PassengerList> passenger = passengerRepo.findById(userId);
		
	  if (!passenger.isPresent()) 
	  {
			
			throw new UserNotFoundException("User not found with Id"+ userId);
			/*
			 * List<Passenger> pass1 = new ArrayList<>(); pass1.add(new Passenger("NA",
			 * "NA", 0, "NA", 00)); BookingFlight booking = new BookingFlight("NA", "NA",
			 * "NA", null, null, null, null); PassengerList pass = new
			 * PassengerList("invalid User", booking, pass1); Map<String, PassengerList>
			 * response = new HashMap<>(); response.put("User Not Found", pass); return
			 * response;
			 */
		} 
	  
		else 
			
		{
			
			int noOfPassengers = passenger.get().getPassengerlist().size();
			Flight updatedFlight = rest.getForObject("http://AdminMicroservice/flights/getFlightById/"+Id, Flight.class);
			updatedFlight.setSeatsRemaining(updatedFlight.getSeatsRemaining()+noOfPassengers);
			rest.put("http://AdminMicroservice/flights/updateFlight/" + Id, updatedFlight);
			passengerRepo.deleteById(userId);
			
		}
		Map<String, PassengerList> response = new HashMap<>();
		
		response.put("Deleted", passenger.get());
		
		return response;
		
	}

	public Map<String, PassengerList> cancelTicketbyPassengerId(String userId, String Id, String passengerId)
	{
		
		Optional<PassengerList> passenger = passengerRepo.findById(userId);
		
		if (!passenger.isPresent()) {
			
			throw new UserNotFoundException(userId);
			/*
			 * List<Passenger> pass1 = new ArrayList<>(); pass1.add(new Passenger("NA",
			 * "NA", 0, "NA", 00)); BookingFlight booking = new BookingFlight("NA", "NA",
			 * "NA", null, null, null, null); PassengerList pass = new
			 * PassengerList("invalid User", booking, pass1); Map<String, PassengerList>
			 * response = new HashMap<>(); response.put("User Not Found", pass); return
			 * response;
			 */
		} 
		
		else
			
		{
			List<Passenger> passengers = passenger.get().getPassengerlist();
			
			Iterator itr = passengers.iterator();
			
			while(itr.hasNext())
			{
				Passenger passengerobject = (Passenger)itr.next();
				
				String passengerId1 = passengerobject.getAadhar();
				
				if(passengerId==passengerId1)
				{
					itr.remove();
				}
				
			}
			
			int noOfPassengers = passengers.size();
			
			Flight updatedFlight = rest.getForObject("http://AdminMicroservice/flights/getFlightById/"+Id, Flight.class);
			
			updatedFlight.setSeatsRemaining(updatedFlight.getSeatsRemaining()+noOfPassengers);
			
			rest.put("http://AdminMicroservice/flights/updateFlight/" + Id, updatedFlight);
			
			passenger.get().setPassengerlist(passengers);
			
			passengerRepo.save(passenger.get());
		}
		
		Map<String, PassengerList> response = new HashMap<>();
		
		response.put("Deleted", passenger.get());
		
		return response;
	}

	

//	public PassengerList getpassengers(String username) {
//		// TODO Auto-generated method stub
//		return null;
//	}

	
}