package com.upendra.ApiGateWay;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlightServiceApiGateWayApplicationTests {

	@Test
	void contextLoads() {
	}

}
